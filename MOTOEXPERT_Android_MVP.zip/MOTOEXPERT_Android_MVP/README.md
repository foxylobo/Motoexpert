# MOTOEXPERT — MVP Android 0.1

Prototipo inicial en Kotlin + Jetpack Compose.

## Incluye
- Pantalla de inicio con módulos principales.
- Formulario para identificar moto por marca, modelo, año y cilindrada.
- Acceso a diagnóstico manual y guiado.
- Resumen de respuestas del diagnóstico guiado.
- Calculadora educativa básica de Ley de Ohm.
- Estructura visual oscura para MOTOEXPERT.

## Abrir
1. Descomprime el ZIP.
2. Abre la carpeta `MOTOEXPERT_Android_MVP` desde Android Studio.
3. Espera la sincronización de Gradle.
4. Ejecuta en un emulador o teléfono Android con depuración USB.

Requisitos recomendados: Android Studio reciente, JDK 17 y Android SDK 35.

## Importante
Esta es una base funcional de navegación e interacción, no una base de datos técnica completa.
Los módulos de manuales, diagramas y especificaciones por modelo deben alimentarse con documentación
verificada y autorizada. No se deben asumir valores de torque, resistencia, voltaje o ajustes universales.
El diagnóstico guiado es orientativo y no confirma averías por sí solo.
