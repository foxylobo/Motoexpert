package com.motoexpert.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF142333)
private val Panel = Color(0xFF20364A)
private val Orange = Color(0xFFFF9D32)
private val Page = Color(0xFF101923)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MotoExpertApp() }
    }
}

@Composable
fun MotoExpertApp() {
    var screen by remember { mutableStateOf("Inicio") }
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var cc by remember { mutableStateOf("") }
    var symptom by remember { mutableStateOf("") }
    var guidedStep by remember { mutableIntStateOf(0) }
    var answers by remember { mutableStateOf(mapOf<Int, String>()) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange,
            secondary = Color(0xFF80CBC4),
            background = Page,
            surface = Navy
        )
    ) {
        Scaffold(
            containerColor = Page,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("MOTOEXPERT", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                            Text("Mecánica • Electricidad • Diagnóstico", fontSize = 10.sp, color = Color.LightGray)
                        }
                    },
                    navigationIcon = {
                        if (screen != "Inicio") {
                            IconButton(onClick = { screen = "Inicio" }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                            }
                        } else {
                            Icon(Icons.Default.TwoWheeler, contentDescription = null,
                                modifier = Modifier.padding(start = 12.dp), tint = Orange)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
                )
            }
        ) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (screen) {
                    "Inicio" -> HomeScreen { screen = it }
                    "Buscar moto" -> BikeSearchScreen(
                        brand, { brand = it }, model, { model = it }, year, { year = it }, cc, { cc = it },
                        onSearch = { screen = "Ficha de moto" }
                    )
                    "Ficha de moto" -> BikeResult(brand, model, year, cc) {
                        screen = "Diagnóstico"
                    }
                    "Diagnóstico" -> DiagnosisScreen(
                        symptom = symptom, onSymptom = { symptom = it },
                        onManual = { screen = "Diagnóstico manual" },
                        onGuided = { guidedStep = 0; answers = emptyMap(); screen = "Diagnóstico guiado" }
                    )
                    "Diagnóstico manual" -> ManualDiagnosis(symptom) { symptom = it }
                    "Diagnóstico guiado" -> GuidedDiagnosis(guidedStep, answers,
                        onAnswer = { answers = answers + (guidedStep to it) },
                        onNext = { if (guidedStep < 4) guidedStep++ else screen = "Resultado guiado" },
                        onBackStep = { if (guidedStep > 0) guidedStep-- }
                    )
                    "Resultado guiado" -> GuidedResult(answers)
                    else -> ModuleScreen(screen)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(open: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Tu taller de motos en el bolsillo", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Aprende, consulta y organiza diagnósticos para todas las marcas y cilindradas.",
                    color = Color.LightGray, fontSize = 13.sp)
                Button(onClick = { open("Buscar moto") }) {
                    Icon(Icons.Default.Search, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Buscar motocicleta")
                }
            }
        }
        val items = listOf(
            Triple("Mecánica", "Motores, transmisión, frenos y suspensión", Icons.Default.Build),
            Triple("Electricidad", "Batería, carga, encendido, luces y sensores", Icons.Default.Bolt),
            Triple("Diagnóstico", "Modo guiado y búsqueda manual de fallas", Icons.Default.Troubleshoot),
            Triple("Diagramas eléctricos", "Esquemas y circuitos por motocicleta", Icons.Default.AccountTree),
            Triple("Manuales técnicos", "Procedimientos y especificaciones", Icons.Default.MenuBook),
            Triple("Calculadoras", "Ley de Ohm y cálculos eléctricos", Icons.Default.Calculate),
            Triple("Cursos", "Desde nivel inicial hasta avanzado", Icons.Default.School),
            Triple("Mi taller", "Historial y mantenimiento de motos", Icons.Default.Garage)
        )
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { item ->
                    Card(
                        modifier = Modifier.weight(1f).height(132.dp).clickable { open(item.first) },
                        colors = CardDefaults.cardColors(containerColor = Navy),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(item.third, null, tint = Orange, modifier = Modifier.size(28.dp))
                            Text(item.first, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(item.second, color = Color.LightGray, fontSize = 11.sp, lineHeight = 14.sp)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text("Versión inicial 0.1 • Contenido técnico en desarrollo", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun BikeSearchScreen(
    brand: String, onBrand: (String) -> Unit,
    model: String, onModel: (String) -> Unit,
    year: String, onYear: (String) -> Unit,
    cc: String, onCc: (String) -> Unit,
    onSearch: () -> Unit
) {
    Text("Identifica tu motocicleta", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Completa los datos para consultar información específica.", color = Color.LightGray)
    OutlinedTextField(brand, onBrand, label = { Text("Marca (ej. Honda)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
    OutlinedTextField(model, onModel, label = { Text("Modelo (ej. CB190R)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
    OutlinedTextField(year, onYear, label = { Text("Año") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
    OutlinedTextField(cc, onCc, label = { Text("Cilindrada (cc)") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
    Button(
        onClick = onSearch,
        enabled = brand.isNotBlank() && model.isNotBlank() && year.isNotBlank() && cc.isNotBlank(),
        modifier = Modifier.fillMaxWidth()
    ) { Text("Guardar datos y continuar") }
}

@Composable
fun BikeResult(brand: String, model: String, year: String, cc: String, diagnose: () -> Unit) {
    Text("Motocicleta seleccionada", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    InfoCard("Marca", brand)
    InfoCard("Modelo", model)
    InfoCard("Año", year)
    InfoCard("Cilindrada", "$cc cc")
    Text("Estos datos identifican la moto en esta versión de prueba. Aún no se consulta una base de datos técnica externa.",
        color = Color.LightGray, fontSize = 12.sp)
    Button(onClick = diagnose, modifier = Modifier.fillMaxWidth()) { Text("Ir al diagnóstico") }
}

@Composable
fun DiagnosisScreen(symptom: String, onSymptom: (String) -> Unit, onManual: () -> Unit, onGuided: () -> Unit) {
    Text("Diagnóstico de fallas", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Puedes buscar directamente un problema o responder preguntas paso a paso.", color = Color.LightGray)
    OutlinedTextField(symptom, onSymptom, label = { Text("Describe el síntoma (opcional)") },
        modifier = Modifier.fillMaxWidth(), minLines = 2)
    Button(onClick = onGuided, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Assistant, null); Spacer(Modifier.width(8.dp)); Text("Diagnóstico guiado")
    }
    OutlinedButton(onClick = onManual, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("Buscar fallas manualmente")
    }
}

@Composable
fun ManualDiagnosis(symptom: String, onSymptom: (String) -> Unit) {
    Text("Biblioteca de fallas", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    OutlinedTextField(symptom, onSymptom, label = { Text("Buscar por síntoma") }, modifier = Modifier.fillMaxWidth())
    val faults = listOf(
        "El motor no arranca" to "Comprobar batería, conexiones, fusible principal, interruptores de seguridad y sistema de arranque.",
        "La batería no carga" to "Revisar conexiones, estator y regulador/rectificador con el procedimiento y valores del fabricante.",
        "Falla de encendido" to "Comprobar bujía, capuchón, bobina, alimentación y sensores según el sistema instalado.",
        "Luces no funcionan" to "Revisar fusible, masa, conectores, interruptores y circuito correspondiente."
    )
    faults.filter { symptom.isBlank() || it.first.contains(symptom, true) || it.second.contains(symptom, true) }
        .forEach { InfoCard(it.first, it.second) }
    Text("Las causas son orientativas. Confirma siempre con el manual de servicio del modelo exacto.",
        color = Color.LightGray, fontSize = 12.sp)
}

@Composable
fun GuidedDiagnosis(
    step: Int, answers: Map<Int, String>, onAnswer: (String) -> Unit,
    onNext: () -> Unit, onBackStep: () -> Unit
) {
    val questions = listOf(
        "¿El tablero enciende al girar la llave?" to listOf("Sí", "No", "Intermitente"),
        "¿La batería está cargada según la especificación del fabricante?" to listOf("Sí", "No", "No lo he medido"),
        "¿El motor de arranque gira?" to listOf("Sí", "No", "No aplica"),
        "¿Se escucha la bomba de combustible, si corresponde?" to listOf("Sí", "No", "No aplica / No sé"),
        "¿Se ha comprobado chispa y alimentación de combustible?" to listOf("Sí", "No", "Todavía no")
    )
    Text("Diagnóstico guiado • Paso ${step + 1} de ${questions.size}", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    LinearProgressIndicator(progress = { (step + 1) / questions.size.toFloat() }, modifier = Modifier.fillMaxWidth())
    Text(questions[step].first, color = Color.White, fontSize = 17.sp)
    questions[step].second.forEach { option ->
        Row(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                .clickable { onAnswer(option) }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = answers[step] == option, onClick = { onAnswer(option) })
            Text(option, color = Color.White)
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onBackStep, enabled = step > 0, modifier = Modifier.weight(1f)) { Text("Anterior") }
        Button(onClick = onNext, enabled = answers.containsKey(step), modifier = Modifier.weight(1f)) {
            Text(if (step == 4) "Ver resumen" else "Siguiente")
        }
    }
    Text("No realices pruebas con el motor en marcha cerca de partes móviles o combustible. Si no tienes experiencia, solicita ayuda técnica.",
        color = Color.LightGray, fontSize = 11.sp)
}

@Composable
fun GuidedResult(answers: Map<Int, String>) {
    Text("Resumen del diagnóstico", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    val labels = listOf("Tablero", "Estado de batería", "Motor de arranque", "Bomba de combustible", "Chispa y combustible")
    labels.forEachIndexed { index, label -> InfoCard(label, answers[index] ?: "Sin respuesta") }
    Text("Siguiente paso: usar el manual de servicio de la moto para realizar las mediciones correspondientes. Este resumen no determina por sí solo una avería.",
        color = Color.LightGray, fontSize = 13.sp)
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Orange, fontWeight = FontWeight.Bold)
            Text(body, color = Color.White)
        }
    }
}

@Composable
fun ModuleScreen(name: String) {
    Text(name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Text("Este módulo está incluido en el proyecto y será desarrollado en la siguiente etapa.", color = Color.LightGray)
    when (name) {
        "Calculadoras" -> CalculatorScreen()
        "Mecánica" -> InfoCard("Mecánica de motos", "Próximamente: motor, distribución, embrague, transmisión, frenos y suspensión.")
        "Electricidad" -> InfoCard("Electricidad de motos", "Próximamente: batería, sistema de carga, encendido, iluminación, sensores y diagramas.")
        "Diagramas eléctricos" -> InfoCard("Diagramas", "Se incorporarán esquemas verificados por marca, modelo, año y versión.")
        "Manuales técnicos" -> InfoCard("Manuales", "Se organizarán manuales propios y documentación autorizada por motocicleta.")
        "Cursos" -> InfoCard("Cursos", "Lecciones para principiantes y módulos técnicos avanzados.")
        "Mi taller" -> InfoCard("Mi taller", "En la siguiente etapa podrás registrar motos, servicios y mantenimientos.")
        else -> InfoCard(name, "Módulo en preparación.")
    }
}

@Composable
fun CalculatorScreen() {
    var voltage by remember { mutableStateOf("12") }
    var resistance by remember { mutableStateOf("6") }
    val result = (voltage.toDoubleOrNull() ?: 0.0) / (resistance.toDoubleOrNull() ?: 0.0).let { if (it == 0.0) 1.0 else it }
    Text("Ley de Ohm: I = V / R", color = Color.White, fontWeight = FontWeight.Bold)
    OutlinedTextField(voltage, { voltage = it }, label = { Text("Voltaje (V)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
    OutlinedTextField(resistance, { resistance = it }, label = { Text("Resistencia (Ω)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
    InfoCard("Corriente calculada", "%.2f A".format(result))
    Text("Ejemplo educativo. No sustituye las especificaciones ni procedimientos del fabricante.", color = Color.LightGray, fontSize = 12.sp)
}
